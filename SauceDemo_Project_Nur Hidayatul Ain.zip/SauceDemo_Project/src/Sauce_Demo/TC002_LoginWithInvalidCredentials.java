package Sauce_Demo;

 
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class TC002_LoginWithInvalidCredentials {

	private WebDriver driver;

	@Before
	public void startUp() {
		
		// Set up WebDriver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\USER\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		// Pre-condition: Go to URL to load the page
		driver.get("https://www.saucedemo.com/");
	

	}
	@Test
	public void LoginWithInvalidCredentials() throws InterruptedException {

	    System.out.println("Testing started for Test Case ID: TC002 - Login With Invalid Credentials ");
	    // Step 1: Open app
	    
	    Thread.sleep(2000);

	 // Test Procedure: Key in test data (username and password)
	 			driver.findElement(By.id("user-name")).sendKeys("standard_user");
	 			driver.findElement(By.id("password")).sendKeys("wrong_pass");

	 			// Test Procedure: Click submit button
	 			driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div/form/input")).click();

	 			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	 			WebElement errorMessage = wait.until(
	 				    ExpectedConditions.visibilityOfElementLocated(
	 				        By.cssSelector("div.error-message-container.error h3[data-test='error']")
	 				    ));

	            // Verify login failure
	            if (errorMessage.isDisplayed()) {
	                System.out.println("Login Failed as expected. Error: " + errorMessage.getText());
	            } else {
	                System.out.println("Test Failed: Error message not shown.");
	            }

	}
    @After
    public void Close() {
        driver.quit();
        System.out.println("Browser closed.");
    }
}

