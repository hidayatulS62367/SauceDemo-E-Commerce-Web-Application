package Sauce_Demo;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class TC001_LoginWithValidCredentials {

	private WebDriver driver;
	
	@Before
	public void startUp() {
		// Set up WebDriver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\USER\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// Pre-condition: Go to URL to load the page
		driver.get("https://www.saucedemo.com/");
	}
	@Test
	public void LoginWithValidCredentials() throws InterruptedException {
	    System.out.println("Testing started for Test Case ID: TC001 - Login With Valid Credentials ");
	    Thread.sleep(2000);
	    
	 // Test Procedure: Key in test data (username and password)
	    driver.findElement(By.id("user-name")).sendKeys("standard_user");
	 	driver.findElement(By.id("password")).sendKeys("secret_sauce");

	 // Test Procedure: Click login button
	 	driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div/form/input")).click();
	 //explicit wait
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
     //if redirect to the next page which is inventory_container,so the login success
	    WebElement inventoryContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container")));
	 // Verify login success
	       if (inventoryContainer.isDisplayed()) {
	           System.out.println("Login: Success.");
	       } else {
	           System.out.println("Login: Failed.");
	       }
	}
    @After
    public void Close() {
        driver.quit();
        System.out.println("Browser closed.");
    }
}

