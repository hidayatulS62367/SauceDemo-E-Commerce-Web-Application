package Sauce_Demo;

import org.junit.Before;

import java.time.Duration;


import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TC005_CheckOutProcess {
	
	private WebDriver driver;

	@Before
	public void startUp() {
	// Set up WebDriver
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\USER\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();

	// Pre-condition: Go to URL to load the page
			driver.get("https://www.saucedemo.com/");

			// Test Procedure: Key in test data (username and password)
			driver.findElement(By.id("user-name")).sendKeys("standard_user");
 			driver.findElement(By.id("password")).sendKeys("secret_sauce");

 			// Test Procedure: Click submit button
 			driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div/form/input")).click();

 			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement inventoryContainer = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container"))
            );
            // Verify login success
            if (inventoryContainer.isDisplayed()) {
                System.out.println("Login: Success.");
            } else {
                System.out.println("Login: Failed.");
            }}
	@Test
	public void CheckOutProcess() throws InterruptedException {

	    System.out.println("Testing started for Test Case ID: TC005 - Check Out Process ");
	    // Step 1: Open app
	    
	    Thread.sleep(2000);

	    

	    driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();

	    // Step 2: Click the shopping cart
	    driver.findElement(By.id("shopping_cart_container")).click();

	    Thread.sleep(2000);
	    driver.findElement(By.id("checkout")).click();
	   
	    
	 // Step 1: Fill in checkout info
	    driver.findElement(By.id("first-name")).sendKeys("hidayatul");
	    driver.findElement(By.id("last-name")).sendKeys("ain");
	    driver.findElement(By.id("postal-code")).sendKeys("22020");
	    Thread.sleep(2000);
	    // Step 2: Click continue button
	    driver.findElement(By.id("continue")).click();

	    // Step 3: Verify input
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

	    try {
	        // If the info is correct, the checkout page continues to next step
	        wait.until(ExpectedConditions.urlContains("checkout-step-two.html"));
	        System.out.println("Test Case Checkout Info: Success. User can continue checkout.");
	    } catch (Exception e) {
	        // If the info is incorrect, an error message appears
	        WebElement errorMessage = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h3[data-test='error']"))
	        );
	        System.out.println("TC Checkout Info: Failed.");
	        System.out.println("Error Message: " + errorMessage.getText());
	    }

	}
    @After
    public void Close() {
        driver.quit();
        System.out.println("Browser closed.");
    }
}
	

