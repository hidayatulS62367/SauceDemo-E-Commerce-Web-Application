package Sauce_Demo;

import org.junit.Before;

import java.time.Duration;
import java.util.List;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TC004_RemoveProductFromCart {
	
	private WebDriver driver;

	@Before
	public void startUp() {
	// Set up WebDriver
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\USER\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();

	// Pre-condition: Go to URL to load the page
			driver.get("https://www.saucedemo.com/");

			// Test Procedure: Key in test data (username and password)
			driver.findElement(By.id("user-name")).sendKeys("standard_user");
 			driver.findElement(By.id("password")).sendKeys("secret_sauce");

 			// Test Procedure: Click submit button
 			driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div/form/input")).click();

 			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement inventoryContainer = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container"))
            );
            // Verify login success
            if (inventoryContainer.isDisplayed()) {
                System.out.println("Login: Success.");
            } else {
                System.out.println("Login: Failed.");
            }}
	@Test
	public void RemoveProductFromCart() throws InterruptedException {
		System.out.println("Testing started for Test Case ID: TC004 - Remove Product From Cart");

		// Step 1: Add the item to the cart
		String expectedItem = "Sauce Labs Backpack";
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

		// Step 2: Click the shopping cart and wait for cart page to load
		driver.findElement(By.id("shopping_cart_container")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cart_list")));

		// Step 3: Verify the item is in the cart
		WebElement cartItem = driver.findElement(By.className("inventory_item_name"));
		String actualItem = cartItem.getText();

		if (actualItem.equals(expectedItem)) {
		    System.out.println("Current item in cart  : " + actualItem);
		} else {
		    System.out.println("TC004 Test Result: Failed. Item not added to cart");
		}

		// Step 4: Remove the item
		WebElement removeButton = wait.until(
		    ExpectedConditions.elementToBeClickable(By.id("remove-sauce-labs-backpack"))
		);
		removeButton.click();

		// Step 5: Wait until cart is empty
		wait.until(ExpectedConditions.invisibilityOf(cartItem));

		// Step 6: Verify cart is empty
		List<WebElement> cartItemsAfterRemove = driver.findElements(By.className("inventory_item_name"));
		if (cartItemsAfterRemove.isEmpty()) {
		    System.out.println("TC004 Test Result: Success.Item has been removed and the cart is empty.");
		} else {
		    System.out.println("TC004 Remove Item Test Result: Failed. Cart still contains items:");
		    for (WebElement item : cartItemsAfterRemove) {
		        System.out.println("- " + item.getText());
		    }
		}

		Thread.sleep(2000);

	}
    @After
    public void Close() {
        driver.quit();
        System.out.println("Browser closed.");
    }
}
	

